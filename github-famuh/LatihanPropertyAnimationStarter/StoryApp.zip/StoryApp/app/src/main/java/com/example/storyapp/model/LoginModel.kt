package com.example.storyapp.model

data class LoginModel(
    val email: String,
    val password: String,
)
