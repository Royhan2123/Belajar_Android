package com.example.storyapp.model

data class RegisterModel(
    val name: String,
    val email: String,
    val password: String,
)