
import com.example.tugasgithubuser.API.DetailuserResponse
import com.example.tugasgithubuser.API.FollowItem
import com.example.tugasgithubuser.API.SearchResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiServices {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getUsers(
    @Query("q") username:String? = null
    ):Call<SearchResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getDetailUser(
        @Path("username") username:String,
    ):Call<DetailuserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollowers(
        @Path("username") username:String
    ):Call<List<FollowItem>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(
        @Path("username") username:String
    ):Call<List<FollowItem>>

}