package com.example.tugasgithubuser.ViewModel

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.tugasgithubuser.API.ApiConfig
import com.example.tugasgithubuser.API.SearchResponse
import com.example.tugasgithubuser.API.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val _listUser = MutableLiveData<List<User>>()
    val listUsers:LiveData<List<User>> = _listUser

    private val _loading = MutableLiveData<Boolean>()
    val isLoading:LiveData<Boolean> = _loading

    companion object{
        private const val TAG = "MainViewModel"
    }
    init {
        SearchUser()
    }
    fun SearchUser(user: String? = "Royhan"){
        _loading.value = true
        val client =ApiConfig.getApiServices().getUsers(username = user)

        client.enqueue(object : Callback<SearchResponse>{
            override fun onResponse(
                call: Call<SearchResponse>,
                response: Response<SearchResponse>
            ) {
                _loading.value = false
                if (response.isSuccessful){
                    _listUser.value =response.body()?.items
                }else{
                Log.e(TAG,"onFailure:${response.message()}")
                }
            }

            override fun onFailure(call: Call<SearchResponse>, t: Throwable) {
                Log.e(TAG,"onFailure:${t.message}")
            }
        })
    }
}