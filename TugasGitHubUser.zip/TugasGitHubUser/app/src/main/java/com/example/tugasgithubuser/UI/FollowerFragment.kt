package com.example.tugasgithubuser.UI

import android.nfc.Tag
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tugasgithubuser.Adapter.FollowerAdapter
import com.example.tugasgithubuser.API.FollowItem
import com.example.tugasgithubuser.ViewModel.DetailViewModel
import com.example.tugasgithubuser.databinding.FragmentFollowerBinding

class FollowerFragment : Fragment() {
    private lateinit var binding: FragmentFollowerBinding
    private val detailViewModel by activityViewModels<DetailViewModel>()

    companion object {
        const val ARG_SECTION_NUMBER = "section_number"
        const val ARG_USERNAME = "arg_username"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowerBinding.inflate(layoutInflater)
        binding.recyclerViewFragment.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(context)
        binding.recyclerViewFragment.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(context, layoutManager.orientation)
        binding.recyclerViewFragment.addItemDecoration(itemDecoration)

        detailViewModel.isLoadingFolls.observe(viewLifecycleOwner) {
            showLoading(it)
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val currentIndex = arguments?.getInt(ARG_SECTION_NUMBER, 0)
        val username = arguments?.getString(ARG_USERNAME)
        Log.d("fragment",currentIndex.toString())
        if (username != null) {
            if (currentIndex == 1) {
                detailViewModel.findUserFollowings(username)
                detailViewModel.userFollowing.observe(viewLifecycleOwner) { follow ->
                    setUserFollowData(follow)
                }
            }

            if (currentIndex == 2) {
                detailViewModel.findUserFollowers(username)
                detailViewModel.userFollowers.observe(viewLifecycleOwner) { follow ->
                    setUserFollowData(follow)
                }
            }
        }
    }

    private fun setUserFollowData(follow: List<FollowItem>) {
        val followAdapter = FollowerAdapter(requireContext(), follow)
        binding.recyclerViewFragment.adapter = followAdapter
    }

    private fun showLoading(loading: Boolean) {
        binding.progresBarFragment.visibility = if (loading) View.VISIBLE else View.GONE
    }
}
