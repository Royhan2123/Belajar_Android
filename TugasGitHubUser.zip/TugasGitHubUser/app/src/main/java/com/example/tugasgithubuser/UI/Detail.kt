package com.example.tugasgithubuser.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.tugasgithubuser.API.DetailuserResponse
import com.example.tugasgithubuser.Adapter.SectionPagerAdapter
import com.example.tugasgithubuser.R
import com.example.tugasgithubuser.ViewModel.DetailViewModel
import com.example.tugasgithubuser.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class Detail : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>()

    companion object {
        const val EXTRA_NAME = "extra_user"
        private val Tab = intArrayOf(
            R.string.detail1, R.string.detail2
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra(EXTRA_NAME)

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        if (username != null) {
            detailViewModel.findDetailUser(username)
            detailViewModel.findUserFollowers(username)
            detailViewModel.findUserFollowings(username)
            detailViewModel.user.observe(this) { user ->
                setUserData(user)
            }
        }

        detailViewModel.userFollowers.observe(this) { fol ->
            val totalFollower = fol.size
            binding.totalFollower.text = totalFollower.toString()
        }

        detailViewModel.userFollowing.observe(this) { fol ->
            val totalFollowing = fol.size
            binding.totalFollowing.text = totalFollowing.toString()
        }

        // layout
        if(username != null) {
            val sectionPagerAdapter = SectionPagerAdapter(this,username)
            val viewPager: ViewPager2 = binding.viewPage
            viewPager.adapter = sectionPagerAdapter

            val tabs: TabLayout = binding.tabs
            TabLayoutMediator(tabs, viewPager) { tab, position ->
                tab.text = resources.getString(Tab[position])
            }.attach()
        }

        supportActionBar?.elevation = 0f
    }

    private fun setUserData(user: DetailuserResponse) {
        binding.username.text = user.login
        binding.name.text = user.name

        Glide.with(this)
            .load(user.avatarUrl)
            .centerCrop()
            .error(R.drawable.ic_launcher_background)
            .into(binding.circleImageView)
    }

    private fun showLoading(loading: Boolean) {
        binding.progressBarDetail.visibility = if (loading) View.VISIBLE else View.GONE
    }
}
